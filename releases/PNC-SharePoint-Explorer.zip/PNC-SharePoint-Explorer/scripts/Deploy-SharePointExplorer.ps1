<#
.SYNOPSIS
  Zero-touch deploy of "SharePoint Explorer" (Power Apps code app) to a Power Platform environment.

.DESCRIPTION
  Installs missing prerequisites, signs you in, picks the environment, wires the SharePoint connector, bakes the app
  OWNER into the bundle (only owners see the Connect screen), builds and publishes with `pac code push`.
  You are the owner by default (the account you sign in with). No Azure app registration is used: the app runs on each
  user's own SharePoint connection.

  The only thing that cannot be scripted is the one-time OAuth sign-in that creates the SharePoint *connection*;
  if it does not exist yet the script opens the right page in your browser and waits for you.

.PARAMETER EnvironmentId     Target environment GUID. Prompted (with a list) if omitted.
.PARAMETER DisplayName       App display name.
.PARAMETER OwnerUpn          App owner(s) allowed to choose the list/library. Default: the signed-in pac user.
.PARAMETER ConfigSiteUrl     SharePoint site that (a) stores the app's shared settings - a small list "SPX_Config" the owner creates there on first
                             Connect - and (b) is used to register the SharePoint connector with `pac` (it needs one site + one existing list
                             to bootstrap; the app itself can then reach ANY site). Strongly recommended.
.PARAMETER AppId             Update this existing app (GUID from make.powerapps.com > Apps > Details) instead of letting pac decide. Use it if the
                             script says an app with this name already exists and it cannot work out which one.
.PARAMETER BootstrapList     Name of an existing list/library on the config site used to register the connector. Default: tries
                             'Documents', 'Shared Documents', 'Site Pages'.
.PARAMETER AddCopilotStudio  Also wire the Microsoft Copilot Studio connector (agent chat in the app).
.PARAMETER NoCopilotStudio   Skip the Copilot Studio question entirely.
.PARAMETER NonInteractive    Never prompt; fail instead.
.PARAMETER SkipPrereqInstall Do not try to install Node.js / Power Platform CLI.

.EXAMPLE
  ./scripts/Deploy-SharePointExplorer.ps1
.EXAMPLE
  ./scripts/Deploy-SharePointExplorer.ps1 -EnvironmentId 00000000-0000-0000-0000-000000000000 -ConfigSiteUrl https://contoso.sharepoint.com/sites/Apps -OwnerUpn alice@contoso.com,bob@contoso.com
#>
[CmdletBinding()]
param(
  [string]$EnvironmentId,
  [string]$DisplayName = 'SharePoint Explorer',
  [string[]]$OwnerUpn,
  [string]$ConfigSiteUrl,
  [string]$BootstrapList,
  [string]$AppId,
  [switch]$AddCopilotStudio,
  [switch]$NoCopilotStudio,
  [switch]$NonInteractive,
  [switch]$SkipPrereqInstall
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$logDir = Join-Path $root '.deploy-logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
try { Start-Transcript -Path (Join-Path $logDir ("deploy-{0:yyyyMMdd-HHmmss}.log" -f (Get-Date))) | Out-Null } catch { }

function Step($m) { Write-Host "`n==> $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "    $m" -ForegroundColor Green }
function Warn($m) { Write-Host "    $m" -ForegroundColor Yellow }
function Have($c) { [bool](Get-Command $c -ErrorAction SilentlyContinue) }
function Ask($prompt) { if ($NonInteractive) { throw "$prompt (required, but -NonInteractive was set)" }; Read-Host $prompt }
function Run {
  param([string]$Exe, [string[]]$Arguments)
  & $Exe @Arguments
  if ($LASTEXITCODE -ne 0) { throw "'$Exe $($Arguments -join ' ')' failed (exit $LASTEXITCODE)" }
}
function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User') + ";$HOME\.dotnet\tools" }
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)   # pac (Node) cannot parse a BOM

try {
  # ---------- 1. prerequisites ----------
  Step 'Checking prerequisites'
  if (-not (Have 'node')) {
    if ($SkipPrereqInstall) { throw 'Node.js is required (https://nodejs.org).' }
    if (Have 'winget') { Warn 'Installing Node.js LTS via winget...'; winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements; Refresh-Path }
    else { throw 'Node.js not found and winget is unavailable. Install Node.js LTS and re-run.' }
  }
  if (-not (Have 'node')) { throw 'Node.js was installed but is not on PATH yet. Open a NEW PowerShell window and re-run.' }
  Ok "node $(node --version)"

  if (-not (Have 'pac')) {
    if ($SkipPrereqInstall) { throw 'Power Platform CLI (pac) is required.' }
    if (Have 'dotnet') { Warn 'Installing Power Platform CLI via dotnet tool...'; dotnet tool install --global Microsoft.PowerApps.CLI.Tool; Refresh-Path }
    elseif (Have 'winget') { Warn 'Installing Power Platform CLI via winget...'; winget install -e --id Microsoft.PowerAppsCLI --accept-source-agreements --accept-package-agreements; Refresh-Path }
    else { throw 'pac not found. Install it from https://aka.ms/PowerAppsCLI and re-run.' }
  }
  if (-not (Have 'pac')) { throw 'pac was installed but is not on PATH yet. Open a NEW PowerShell window and re-run.' }
  Ok 'Power Platform CLI present'

  # ---------- 2. sign in ----------
  Step 'Signing in (a browser window opens)'
  $who = (& pac auth who 2>&1) | Out-String
  if ($who -notmatch '(?i)Tenant|User') { Run pac @('auth','create'); $who = (& pac auth who 2>&1) | Out-String } else { Ok 'Existing pac profile found' }
  $signedIn = $null
  if ($who -match '(?i)(?:User|Name)\s*:?\s*([^\s@]+@[^\s]+)') { $signedIn = $Matches[1].Trim() }
  elseif ($who -match '([A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})') { $signedIn = $Matches[1] }

  # ---------- 3. environment ----------
  Step 'Choosing target environment'
  if (-not $EnvironmentId) {
    Write-Host ((& pac env list 2>&1) | Out-String)
    $EnvironmentId = Ask 'Enter the Environment ID (GUID) to deploy to'
  }
  $EnvironmentId = $EnvironmentId.Trim()
  if ($EnvironmentId -notmatch '^[0-9a-fA-F-]{36}$') { throw "'$EnvironmentId' is not a valid environment GUID." }
  Run pac @('env','select','--environment',$EnvironmentId)
  Ok "Target: $EnvironmentId"

  # ---------- 4. owner + config ----------
  Step 'Configuring app owner'
  if (-not $OwnerUpn -or -not $OwnerUpn.Count) {
    if ($signedIn) { $OwnerUpn = @($signedIn); Ok "Owner = signed-in user $signedIn" }
    else { $OwnerUpn = @((Ask 'Owner e-mail / UPN (the person who may choose the list or library)')) }
  }
  $OwnerUpn = @($OwnerUpn | ForEach-Object { $_ -split '[,;]' } | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })
  if (-not $OwnerUpn.Count) { throw 'At least one owner is required.' }
  Ok "Owners: $($OwnerUpn -join ', ')"

  # ---------- 5. install + init ----------
  Step 'Installing npm packages'
  Run npm @('install','--no-audit','--no-fund')

  Step 'Initialising code app'
  $cfgPath   = Join-Path $root 'power.config.json'
  $stateDir  = Join-Path (Join-Path $root '.deploy-state') $EnvironmentId     # each environment has its own app id + connections
  $cfgBackup = Join-Path $stateDir 'power.config.json'
  function Save-ConfigBackup { if (Test-Path $cfgPath) { New-Item -ItemType Directory -Force -Path $stateDir | Out-Null; Copy-Item $cfgPath $cfgBackup -Force } }

  if (Test-Path $cfgPath) {  # folder last used for ANOTHER environment: park its files so they do not leak into this deployment
    $otherEnv = $null
    try { $otherEnv = ([System.IO.File]::ReadAllText($cfgPath).TrimStart([char]0xFEFF) | ConvertFrom-Json).environmentId } catch { }
    if ($otherEnv -and $otherEnv -ne $EnvironmentId) {
      $parked = Join-Path (Join-Path $root '.deploy-state') $otherEnv
      New-Item -ItemType Directory -Force -Path $parked | Out-Null
      Copy-Item $cfgPath (Join-Path $parked 'power.config.json') -Force
      Remove-Item $cfgPath -Force
      foreach ($d in @('.power','src\generated')) { $dp = Join-Path $root $d; if (Test-Path $dp) { Remove-Item $dp -Recurse -Force } }
      Warn "This folder was set up for environment $otherEnv - parked its config and starting clean for $EnvironmentId."
    }
  }
  if (-not (Test-Path $cfgPath) -and (Test-Path $cfgBackup)) { Copy-Item $cfgBackup $cfgPath -Force; Ok 'Restored power.config.json from the previous deploy (keeps the same app)' }
  if (-not (Test-Path $cfgPath)) { Run pac @('code','init','--displayName',$DisplayName) } else { Ok 'power.config.json exists - reusing' }
  Save-ConfigBackup

  # ---------- 6. SharePoint connection ----------
  Step 'Wiring the SharePoint connector (uses each user''s own connection - no app registration)'
  function Get-Connections {
    $out = (& pac connection list 2>&1) | Out-String
    foreach ($line in ($out -split "`n")) {
      if ($line -match '(?i)\b([0-9a-f]{32}|[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})\b.*?(shared_[a-z0-9_\-]+)') { [pscustomobject]@{ Id = $Matches[1]; Api = $Matches[2].ToLower() } }
      elseif ($line -match '(?i)(shared_[a-z0-9_\-]+).*?\b([0-9a-f]{32}|[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})\b') { [pscustomobject]@{ Id = $Matches[2]; Api = $Matches[1].ToLower() } }
    }
  }
  $api = 'shared_sharepointonline'
  $attempt = 0
  while (-not (@(Get-Connections) | Where-Object { $_.Api -eq $api })) {
    if ($NonInteractive) { throw "No SharePoint connection exists in environment $EnvironmentId. Create one at https://make.powerapps.com/environments/$EnvironmentId/connections and re-run." }
    Warn 'The SharePoint connection must be created once (OAuth sign-in cannot be scripted).'
    Warn 'Opening your browser: click "Create" and sign in.'
    Start-Process "https://make.powerapps.com/environments/$EnvironmentId/connections/available?apiName=$api"
    $null = Read-Host 'Press Enter when the connection is created'
    if (++$attempt -ge 10) { throw 'SharePoint connection still missing after 10 checks.' }
  }
  $conn = @(Get-Connections) | Where-Object { $_.Api -eq $api } | Select-Object -First 1
  # A restored power.config.json may point at a connection/app that no longer exists: start clean when it names a different connection
  if (Test-Path $cfgPath) {
    $rawCfg = [System.IO.File]::ReadAllText($cfgPath)
    $ids = [regex]::Matches($rawCfg, '[0-9a-fA-F]{32}|[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}') | ForEach-Object { $_.Value.ToLower() }
    if ($rawCfg -match 'connectionReferences' -and $rawCfg -match 'shared_sharepointonline' -and ($ids -notcontains $conn.Id.ToLower())) {
      Warn 'power.config.json refers to a different SharePoint connection than the one that exists now - clearing the old binding.'
      try { $j = $rawCfg.TrimStart([char]0xFEFF) | ConvertFrom-Json; foreach ($k in 'connectionReferences','databaseReferences','dataSources') { if ($j.PSObject.Properties[$k]) { $j.$k = [pscustomobject]@{} } }; [System.IO.File]::WriteAllText($cfgPath, ($j | ConvertTo-Json -Depth 20), $utf8NoBom) } catch { }
      $dp = Join-Path $root '.power'; if (Test-Path $dp) { Remove-Item $dp -Recurse -Force }
    }
  }

  # No config site given: discover one from the user's own SharePoint connection (asked only if discovery finds nothing)
  if (-not $ConfigSiteUrl) {
    foreach ($cmd in @(@('code','list-datasets','-a',$api,'-c',$conn.Id), @('code','list-datasets','--apiId',$api,'--connectionId',$conn.Id))) {
      $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
      $dsOut = (& pac @cmd 2>&1) | Out-String
      $ErrorActionPreference = $prev
      $urls = @([regex]::Matches($dsOut, 'https://[A-Za-z0-9.\-]+\.sharepoint\.[a-z]+/[^\s"''|,;]*') | ForEach-Object { $_.Value.TrimEnd('/') } | Select-Object -Unique)
      if ($urls.Count) { $ConfigSiteUrl = ($urls | Where-Object { $_ -match '/(sites|teams)/' } | Select-Object -First 1); if (-not $ConfigSiteUrl) { $ConfigSiteUrl = $urls[0] }; Ok "Using SharePoint site $ConfigSiteUrl for shared settings"; break }
    }
  }
  if (-not $ConfigSiteUrl -and -not $NonInteractive) { do { $ConfigSiteUrl = (Read-Host 'Could not detect a SharePoint site. Config site URL (required, e.g. https://contoso.sharepoint.com/sites/Apps)').Trim() } while (-not $ConfigSiteUrl) }
  if (-not $ConfigSiteUrl) { throw 'A config site is required: without it other users cannot see which list the owner connected. Re-run with -ConfigSiteUrl https://<tenant>.sharepoint.com/sites/<site>.' }
  if ($ConfigSiteUrl) { $ConfigSiteUrl = $ConfigSiteUrl.TrimEnd('/') }
  $appConfig = [ordered]@{ owners = $OwnerUpn; configSiteUrl = "$ConfigSiteUrl"; configList = 'SPX_Config' }
  [System.IO.File]::WriteAllText((Join-Path $root 'src\appconfig.json'), (($appConfig | ConvertTo-Json -Depth 4) + "`n"), $utf8NoBom)

  function Add-Source([string[]]$Extra) {   # true when pac accepted it (or it is already there)
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $o = (& pac code add-data-source -a $api -c $conn.Id @Extra 2>&1) | Out-String
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prev
    if ($code -eq 0 -or $o -match '(?i)already') { return $true }
    Write-Host "    (pac said: $(($o -replace '\s+',' ').Trim()))" -ForegroundColor DarkGray
    return $false
  }
  # SharePoint is a *tabular* connector: pac wants one site (dataset) and one existing list (table) to register it. The app itself
  # reaches any site/list at run time, so which list is used here does not matter.
  $added = Add-Source @()
  if (-not $added -and $ConfigSiteUrl) {
    $tables = @($BootstrapList, 'Documents', 'Shared Documents', 'Site Pages') | Where-Object { $_ } | Select-Object -Unique
    foreach ($t in $tables) { if (Add-Source @('-d', $ConfigSiteUrl, '-t', $t)) { $added = $true; Ok "Registered with $ConfigSiteUrl / $t"; break } }
    if (-not $added -and -not $NonInteractive) {
      $t = (Read-Host "Name of any existing list or library on $ConfigSiteUrl").Trim()
      if ($t -and (Add-Source @('-d', $ConfigSiteUrl, '-t', $t))) { $added = $true }
    }
  }
  if (-not $added) { throw "Could not add the SharePoint connector. Run manually:  pac code add-data-source -a $api -c $($conn.Id) -d <site url> -t <existing list name>   then re-run this script." }
  Ok "SharePoint connector added ($($conn.Id))"

  # ---------- 6b. Copilot Studio agent chat (optional; failures here never stop the deployment) ----------
  if (-not $NoCopilotStudio) {
    try {
      $csApi = 'shared_microsoftcopilotstudio'
      $csConn = @(Get-Connections) | Where-Object { $_.Api -eq $csApi } | Select-Object -First 1
      $want = [bool]$AddCopilotStudio -or [bool]$csConn
      if (-not $want -and -not $NonInteractive) {
        $a = (Read-Host 'Add AI assistant support (chat with a Copilot Studio agent inside the app)? [y/N]').Trim()
        $want = $a -match '^(y|yes)$'
      }
      if ($want) {
        Step 'Wiring the Copilot Studio connector (agent chat)'
        if (-not $csConn -and -not $NonInteractive) {
          Warn 'Create the "Microsoft Copilot Studio" connection once (sign-in cannot be scripted). Opening your browser...'
          Start-Process "https://make.powerapps.com/environments/$EnvironmentId/connections/available?apiName=$csApi"
          $null = Read-Host 'Press Enter when the connection is created'
          $csConn = @(Get-Connections) | Where-Object { $_.Api -eq $csApi } | Select-Object -First 1
        }
        if ($csConn) {
          $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
          $o = (& pac code add-data-source -a $csApi -c $csConn.Id 2>&1) | Out-String; $code = $LASTEXITCODE
          $ErrorActionPreference = $prev
          if ($code -eq 0 -or $o -match '(?i)already') { Ok 'Copilot Studio connector added. Add agents later in the app: Assistant -> Setup.' }
          else { Warn "Could not add the Copilot Studio connector (pac said: $(($o -replace '\s+',' ').Trim())). The app works without it; agents can still be added as links." }
        } else { Warn 'No Copilot Studio connection found - skipped. Re-run later with -AddCopilotStudio, or add agents as links in the app.' }
      }
    } catch { Warn "Copilot Studio step skipped: $($_.Exception.Message)" }
  }

  # The app compiles the data-source description pac generates into itself. If it is missing, the app cannot reach SharePoint.
  $schema = @('.power\schemas\appschemas\dataSourcesInfo.ts', '.power\appschemas\dataSourcesInfo.ts') | Where-Object { Test-Path (Join-Path $root $_) } | Select-Object -First 1
  if (-not $schema) {
    Warn 'pac did not generate .power\...\dataSourcesInfo.ts (it reported the data source as already present). Re-registering from a clean state...'
    $raw = if (Test-Path $cfgPath) { [System.IO.File]::ReadAllText($cfgPath).TrimStart([char]0xFEFF) } else { $null }
    if ($raw) { try { $j = $raw | ConvertFrom-Json; foreach ($k in 'connectionReferences','databaseReferences','dataSources') { if ($j.PSObject.Properties[$k]) { $j.$k = [pscustomobject]@{} } }; [System.IO.File]::WriteAllText($cfgPath, ($j | ConvertTo-Json -Depth 20), $utf8NoBom) } catch { } }
    $null = Add-Source @(); if (-not (Test-Path (Join-Path $root '.power\schemas\appschemas\dataSourcesInfo.ts'))) { $null = Add-Source @('-d', $ConfigSiteUrl, '-t', $(if ($BootstrapList) { $BootstrapList } else { 'Documents' })) }
    $schema = @('.power\schemas\appschemas\dataSourcesInfo.ts', '.power\appschemas\dataSourcesInfo.ts') | Where-Object { Test-Path (Join-Path $root $_) } | Select-Object -First 1
  }
  if (-not $schema) { throw 'pac did not generate the data-source schema (.power\schemas\appschemas\dataSourcesInfo.ts). Without it the app would show no SharePoint data. Delete power.config.json and the .power folder, then run this script again.' }
  Ok "Data-source schema present ($schema)"

  # ---------- 7. build ----------
  Step 'Building'
  & npm run build
  if ($LASTEXITCODE -ne 0) {   # pac sometimes generates TypeScript that does not compile; the app does not import it
    Warn 'Type-checked build failed - retrying with a plain bundle.'
    Run npx @('vite','build')
  }
  if (-not (Test-Path (Join-Path $root 'dist\index.html'))) { throw 'Build produced no dist\index.html' }
  Ok 'Build OK'
  # the data-source key that pac generated must appear in the bundle (a generic word like dataSourceType would also be in our own code)
  $schemaFile = @('.power\schemas\appschemas\dataSourcesInfo.ts', '.power\appschemas\dataSourcesInfo.ts') | Where-Object { Test-Path (Join-Path $root $_) } | Select-Object -First 1
  $dsKey = $null
  if ($schemaFile) { $m = [regex]::Match([System.IO.File]::ReadAllText((Join-Path $root $schemaFile)), '["'']?([A-Za-z0-9_\-]+)["'']?\s*:\s*\{\s*["'']?tableId'); if ($m.Success) { $dsKey = $m.Groups[1].Value } }
  if ($dsKey) {
    if (-not (Select-String -Path (Join-Path $root 'dist\assets\*.js') -Pattern ([regex]::Escape($dsKey)) -Quiet)) { throw "The built app does not contain the SharePoint data source '$dsKey': it would run without live data. Check the pac output above and re-run." }
    Ok "Bundle contains data source '$dsKey'"
  } else { Warn 'Could not read the data-source key from the generated schema; skipping the bundle check.' }
  $pkgVer = (Get-Content (Join-Path $root 'package.json') -Raw | ConvertFrom-Json).version
  Ok "Build stamp: v$pkgVer (shown in the app footer)"

  # ---------- 8. publish ----------
  Step 'Publishing to Power Platform'
  function Push-App {   # pac exits 0 even when the service rejects the push, so judge success by its output
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $text = (& pac code push 2>&1 | ForEach-Object { $_.ToString() }) -join "`n"
    $ErrorActionPreference = $prev
    Write-Host $text
    return $text
  }
  function Set-AppId([string]$id) {
    $raw = [System.IO.File]::ReadAllText($cfgPath).TrimStart([char]0xFEFF)
    if ($raw -match '"appId"\s*:') { $raw = [regex]::Replace($raw, '"appId"\s*:\s*(null|"[^"]*")', '"appId": "' + $id + '"') }
    else { $raw = [regex]::Replace($raw, '^\s*\{', '{' + "`n  `"appId`": `"$id`",", 1) }
    [System.IO.File]::WriteAllText($cfgPath, $raw, $utf8NoBom)
  }
  if ($AppId) { Set-AppId $AppId.Trim(); Ok "Updating app $AppId" }
  $configBefore = if (Test-Path $cfgPath) { [System.IO.File]::ReadAllText($cfgPath) } else { $null }
  $out = Push-App
  if ($configBefore -and -not (Test-Path $cfgPath)) { [System.IO.File]::WriteAllText($cfgPath, $configBefore, $utf8NoBom); Warn 'pac removed power.config.json - restored it' }

  if ($out -match 'ApplicationDisplayNameIsInUse') {   # an app with this name already exists: update THAT app (never publish a second, differently named copy)
    $existing = $null
    if ($out -match "Existing App: '([0-9a-fA-F-]{36})'") { $existing = $Matches[1] }
    else { $existing = ([regex]::Matches($out, '[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}') | ForEach-Object { $_.Value } | Where-Object { $_ -ne $EnvironmentId } | Select-Object -First 1) }
    if (-not $existing) { throw "An app named '$DisplayName' already exists in this environment but its id could not be read from pac's message. Open make.powerapps.com > Apps > $DisplayName > Details, copy the App ID and run again with -AppId <id> (or delete the old app first). Not publishing a duplicate on purpose." }
    Warn "An app named '$DisplayName' already exists ($existing). Updating that app..."
    Set-AppId $existing
    $out = Push-App
    if (-not (Test-Path $cfgPath) -and $configBefore) { [System.IO.File]::WriteAllText($cfgPath, $configBefore, $utf8NoBom); Set-AppId $existing }
  }
  if ($out -notmatch '(?i)pushed successfully') {
    if (-not (Test-Path $cfgPath) -and (Test-Path $cfgBackup)) { Copy-Item $cfgBackup $cfgPath -Force }
    throw 'Publish failed (see the pac message above).'
  }
  Save-ConfigBackup

  $playUrl = if ($out -match '(https://apps\.powerapps\.com/play/\S+)') { $Matches[1] } else { $null }
  Write-Host "`nDone. App published." -ForegroundColor Green
  if ($playUrl) { Write-Host "Open it: $playUrl" -ForegroundColor Green }
  $finalId = try { ([System.IO.File]::ReadAllText($cfgPath).TrimStart([char]0xFEFF) | ConvertFrom-Json).appId } catch { $null }
  Write-Host "Or: https://make.powerapps.com/environments/$EnvironmentId/apps  (look for '$DisplayName'; app id: $finalId)." -ForegroundColor Green
  Write-Host "IMPORTANT: close any open tab of the app, reopen it from that Apps list in environment $EnvironmentId and press Ctrl+F5. The footer must say 'Build v$pkgVer · live SharePoint data'. If it still shows an older build or a SAMPLE DATA bar, you are opening a different/older copy of the app." -ForegroundColor Yellow
  Write-Host ''
  Write-Host 'Next steps' -ForegroundColor Cyan
  Write-Host "  1. Open the app -> approve the SharePoint consent prompt -> Connect tab -> pick the site, list or library -> press Connect." -ForegroundColor Gray
  Write-Host "  2. Share the app with your users in make.powerapps.com (they need a Power Apps premium licence for code apps and SharePoint access to the data)." -ForegroundColor Gray
  if ($ConfigSiteUrl) { Write-Host "  3. Give users READ and owners EDIT permission on the '$($appConfig.configList)' list at $ConfigSiteUrl (created on first Connect) so only owners can change the shared settings." -ForegroundColor Gray }
  Write-Host 'Keep power.config.json - it links this folder to the published app for future updates.' -ForegroundColor Gray
}
finally {
  try { Stop-Transcript | Out-Null } catch { }
}
