import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import type { Engine } from '../engine'
import { isEditable } from '../editable'
import type { Attachment, Principal, Row, SpField } from '../types'
import { bytes, dateOnlyDay, lsGet, lsSet, relTime } from '../util'
import { FileGlyph } from './FileGlyph'
import { PrincipalPicker } from './Permissions'
import { Icon, Modal, hashColor, initials, useToast } from './ui'

type Val = string | boolean | string[] | Principal[] | { url: string; desc: string }

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`   // local calendar day, not UTC
function initial(f: SpField, row: Row | null): Val {
  const v = row?.[f.internal]
  switch (f.kind) {
    case 'boolean': return v == null ? '' : v === true || v === 'true' || v === 'Yes' ? 'true' : 'false'
    case 'date': return v ? (f.dateOnly ? dateOnlyDay(String(v)) : String(v).slice(0, 10)) : ''
    case 'multichoice': return Array.isArray(v) ? v.map(String) : v ? String(v).split('; ').filter(Boolean) : []
    case 'user': { const names = Array.isArray(v) ? v.map(String) : v ? String(v).split('; ').filter(Boolean) : []; const ids: number[] = row?.[f.internal + '__ids'] ?? []; return names.map((title, i) => ({ id: ids[i] ?? 0, title, login: '', kind: 'user' as const })) }
    case 'url': return { url: v?.Url ?? '', desc: v?.Description ?? '' }
    default: return v == null ? '' : f.percent && f.kind === 'number' ? String(Math.round(Number(v) * 100)) : String(v)
  }
}
const same = (a: Val, b: Val) => JSON.stringify(a) === JSON.stringify(b)

function Section({ title, icon, hint, children }: { title: string; icon: string; hint?: string; children: ReactNode }) {
  return <section className="ip-sec"><h3><span aria-hidden="true">{icon}</span>{title}{hint && <small className="ip-hint">{hint}</small>}</h3><div className="ip-grid">{children}</div></section>
}

export function ItemPanel({ engine, row, prefill, preset, onSave, onClose }: { engine: Engine; row: Row | null; /** new item copied from this one */ prefill?: Row | null; /** values to start a new item with (e.g. a calendar date) */ preset?: Record<string, string>; onSave: (values: Record<string, unknown>, files: File[], again: boolean) => Promise<void>; onClose: () => void }) {
  const toast = useToast()
  const fields = useMemo(() => engine.fields.filter((f) => engine.select.includes(f.internal) && isEditable(f)), [engine])
  const draftKey = `spx.draft.${engine.src.id}`
  const seed = (r: Row | null): Record<string, Val> => {
    const v = Object.fromEntries(fields.map((f) => [f.internal, initial(f, r)])) as Record<string, Val>
    if (!row && prefill && v[engine.src.isLibrary ? 'FileLeafRef' : 'Title'] !== undefined) { const k = engine.src.isLibrary ? 'FileLeafRef' : 'Title'; v[k] = `${v[k]} (copy)` }
    for (const [k, x] of Object.entries(preset ?? {})) if (k in v) v[k] = x
    return v
  }
  const [vals, setVals] = useState<Record<string, Val>>(() => seed(row ?? prefill ?? null))
  const [base, setBase] = useState<Record<string, Val>>(() => (row ? seed(row) : Object.fromEntries(fields.map((f) => [f.internal, initial(f, null)])) as Record<string, Val>))
  const [draft, setDraft] = useState<{ vals: Record<string, Val>; at: number } | null>(() => (row || prefill || preset ? null : lsGet(draftKey, null)))
  const [tab, setTab] = useState(0)
  const [onePage, setOnePage] = useState<boolean>(lsGet('spx.onepage', false))
  const [err, setErr] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [atts, setAtts] = useState<Attachment[] | null>(null)
  const [attOk, setAttOk] = useState(!engine.src.isLibrary)
  const [leave, setLeave] = useState(false)
  const body = useRef<HTMLDivElement>(null)
  const set = (k: string, v: Val) => { setVals((c) => ({ ...c, [k]: v })); setErr((c) => ({ ...c, [k]: '' })) }
  const dirty = fields.some((f) => !same(vals[f.internal], base[f.internal])) || files.length > 0
  const req = fields.filter((f) => f.required)
  const filled = req.filter((f) => { const v = vals[f.internal]; return Array.isArray(v) ? v.length : typeof v === 'object' ? (v as { url: string }).url : v !== '' }).length

  useEffect(() => { // autosave a draft of a NEW item so a closed tab or a crash never loses typing
    if (row || !dirty) return
    const h = setTimeout(() => lsSet(draftKey, { vals, at: Date.now() }), 600)
    return () => clearTimeout(h)
  }, [vals, dirty]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { // existing attachments
    if (!row || engine.src.isLibrary) return
    engine.backend.listAttachments(engine.src, row.__id).then(setAtts).catch(() => setAttOk(false))
  }, [row?.__id]) // eslint-disable-line react-hooks/exhaustive-deps

  const validate = () => {
    const e: Record<string, string> = {}
    for (const f of fields) {
      const v = vals[f.internal]
      const empty = Array.isArray(v) ? !v.length : typeof v === 'object' ? !(v as { url: string }).url : v === ''
      if (f.required && empty) e[f.internal] = 'This field is required'
      if ((f.kind === 'number' || f.kind === 'currency') && typeof v === 'string' && v !== '' && isNaN(Number(v))) e[f.internal] = 'Enter a number'
      if (f.kind === 'url' && !empty && !/^https?:\/\//i.test((v as { url: string }).url)) e[f.internal] = 'Enter a full web address starting with https://'
    }
    setErr(e)
    const firstBad = Object.keys(e)[0]
    if (firstBad) { const t = tabs.findIndex((x) => x.fields.some((f) => f.internal === firstBad)); if (t >= 0) setTab(t) }
    if (Object.keys(e).length) { setTimeout(() => { const el = body.current?.querySelector<HTMLElement>('[aria-invalid="true"]') ?? body.current?.querySelector<HTMLElement>('.ip-err')?.closest('.ip-field')?.querySelector<HTMLElement>('button,input,select,textarea'); el?.focus(); el?.scrollIntoView({ block: 'center' }) }, 30); return false }
    return true
  }
  const submit = async (again = false) => {
    if (!validate()) return
    const out: Record<string, unknown> = {}
    for (const f of fields) {
      const v = vals[f.internal]
      if (row ? same(v, base[f.internal]) : (Array.isArray(v) ? !v.length : typeof v === 'object' ? !(v as { url: string }).url : v === '')) continue
      out[f.internal] = f.kind === 'boolean' ? (v === '' ? null : v === 'true') : v
    }
    if (row && !Object.keys(out).length && !files.length) { onClose(); return }
    setBusy(true)
    try {
      await onSave(out, files, again)
      if (!row) { try { localStorage.removeItem(draftKey) } catch { /* ignore */ } }
      if (again) { const fresh = Object.fromEntries(fields.map((f) => [f.internal, initial(f, null)])); setVals(fresh); setBase(fresh); setFiles([]); toast('good', 'Created — add another') }
    } catch (e) { toast('bad', (e as Error).message); setBusy(false); return }
    setBusy(false)
  }
  const tryClose = () => (dirty ? setLeave(true) : onClose())
  const discard = () => { if (!row) { try { localStorage.removeItem(draftKey) } catch { /* ignore */ } } onClose() }
  const title = row ? String(row[engine.src.isLibrary ? 'FileLeafRef' : 'Title'] ?? `Item ${row.__id}`) : 'New item'

  const addFiles = (fl: FileList | File[] | null) => { if (!fl) return; const arr = Array.from(fl); setFiles((c) => [...c, ...arr]) }   // copy NOW: an <input>'s FileList empties when its value is reset
  const tabs = useMemo(() => buildTabs(fields), [fields])
  const attTab = attOk && !engine.src.isLibrary
  const tabbed = !onePage && fields.length > 8
  const total = tabs.length + (attTab ? 1 : 0)
  const miss = (fs: SpField[]) => fs.filter((f) => { const v = vals[f.internal]; return f.required && (Array.isArray(v) ? !v.length : typeof v === 'object' ? !(v as { url: string }).url : v === '') }).length
  const tabKey = (e: React.KeyboardEvent) => { if (e.key === 'ArrowRight') { e.preventDefault(); setTab((t) => (t + 1) % total) } if (e.key === 'ArrowLeft') { e.preventDefault(); setTab((t) => (t - 1 + total) % total) } if (e.key === 'Home') setTab(0); if (e.key === 'End') setTab(total - 1) }
  const activeTab = Math.min(tab, Math.max(0, total - 1))

  return (
    <Modal title={row ? `Edit ${title}` : 'New item'} onClose={tryClose} side className={`ipanel${tabbed ? ' wide' : ''}`}>
      <div className="ip-head">
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="ip-kicker">{row ? 'Edit' : prefill ? 'Duplicate' : 'Create'} · {engine.src.label}</div>
          <h2 style={{ display: 'flex', gap: 10, alignItems: 'center' }}>{engine.src.isLibrary && row && <FileGlyph name={title} folder={row.FSObjType === 1} size={28} />}<span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{title}</span></h2>
          {req.length > 0 && <div className="ip-prog" aria-label={`${filled} of ${req.length} required fields complete`}><i style={{ width: `${(filled / req.length) * 100}%` }} /></div>}
        </div>
        {fields.length > 8 && <button className="btn sm" aria-pressed={onePage} onClick={() => { setOnePage(!onePage); lsSet('spx.onepage', !onePage) }} title="Switch between tabs and one long page">{onePage ? 'Use tabs' : 'One page'}</button>}
        <button className="btn icon" onClick={tryClose} aria-label="Close"><Icon n="x" /></button>
      </div>
      {draft && <div className="banner info" role="status" style={{ margin: '10px 20px 0' }}><Icon n="info" /><div style={{ flex: 1 }}>You have an unsaved draft from {relTime(new Date(draft.at).toISOString())}.</div><button className="btn sm" onClick={() => { setVals(draft.vals); setDraft(null) }}>Resume</button><button className="btn sm ghost" onClick={() => { try { localStorage.removeItem(draftKey) } catch { /* ignore */ } setDraft(null) }}>Discard</button></div>}
      {tabbed && (
        <div role="tablist" aria-label="Form sections" className="ip-tabs" onKeyDown={tabKey}>
          {[...tabs.map((t) => ({ title: t.title, icon: t.icon, n: t.fields.length, m: miss(t.fields), bad: t.fields.some((f) => err[f.internal]), hint: t.hint })), ...(attTab ? [{ title: 'Attachments', icon: '📎', n: files.length + (atts?.length ?? 0), m: 0, bad: false, hint: 'Files attached to this item' }] : [])].map((t, i) => (
            <button key={t.title} role="tab" id={`iptab-${i}`} aria-selected={activeTab === i} aria-controls={`ippanel-${i}`} tabIndex={activeTab === i ? 0 : -1} className={`ip-tab${t.bad ? ' bad' : ''}`} onClick={() => setTab(i)} title={t.hint}>
              <span aria-hidden="true">{t.icon}</span>{t.title}{t.m > 0 ? <span className="pill bad" title={`${t.m} required field(s) empty`}>{t.m}</span> : t.n > 0 && t.title === 'Attachments' ? <span className="pill">{t.n}</span> : null}
            </button>
          ))}
        </div>
      )}

      <div className="ip-body" ref={body} onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); void submit() } }}>
        {tabs.map((t, i) => (
          <div key={t.id} id={`ippanel-${i}`} role={tabbed ? 'tabpanel' : undefined} aria-labelledby={tabbed ? `iptab-${i}` : undefined} hidden={tabbed && activeTab !== i}>
            <Section title={t.title} icon={t.icon} hint={t.hint}>
              {t.fields.map((f) => <Field key={f.internal} f={f} v={vals[f.internal]} set={(v) => set(f.internal, v)} err={err[f.internal]} engine={engine} />)}
            </Section>
          </div>
        ))}
        {!tabs.length && <p className="muted">This {engine.src.isLibrary ? 'file' : 'list'} has no columns the app can edit.</p>}

        {attOk && !engine.src.isLibrary && (
          <div id={`ippanel-${tabs.length}`} role={tabbed ? 'tabpanel' : undefined} aria-labelledby={tabbed ? `iptab-${tabs.length}` : undefined} hidden={tabbed && activeTab !== tabs.length}>
          <Section title="Attachments" icon="📎">
            <div className="ip-full">
              <div className="ip-drop" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files) }}>
                <label className="btn"><Icon n="plus" size={15} />Add files<input type="file" multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = '' }} /></label>
                <span className="muted small">or drop files here{row ? '' : ' — they upload right after the item is created'}</span>
              </div>
              <ul className="upl" style={{ marginTop: 8 }}>
                {(atts ?? []).map((a) => (
                  <li key={a.name}><FileGlyph name={a.name} size={22} /><a className="nm" href={a.url} target="_blank" rel="noreferrer noopener">{a.name}</a><span />
                    <button type="button" className="btn icon sm ghost" aria-label={`Remove attachment ${a.name}`} onClick={async () => { try { await engine.backend.deleteAttachment(engine.src, row!.__id, a.name); setAtts((c) => c!.filter((x) => x.name !== a.name)) } catch (e) { toast('bad', (e as Error).message) } }}><Icon n="trash" size={14} /></button></li>
                ))}
                {files.map((f, i) => <li key={i}><FileGlyph name={f.name} size={22} /><span className="nm">{f.name}</span><span className="muted small">{bytes(f.size)}</span><button type="button" className="btn icon sm ghost" aria-label={`Remove ${f.name}`} onClick={() => setFiles((c) => c.filter((_, j) => j !== i))}><Icon n="x" size={14} /></button></li>)}
              </ul>
            </div>
          </Section>
          </div>
        )}
      </div>

      <div className="ip-foot">
        <span className="muted small" aria-live="polite">{dirty ? '● Unsaved changes' : 'No changes'} · <kbd>Ctrl</kbd>+<kbd>Enter</kbd> to save</span>
        <span className="grow" />
        {tabbed && <><button className="btn" disabled={activeTab === 0} onClick={() => setTab(activeTab - 1)}>← Back</button><button className="btn" disabled={activeTab >= total - 1} onClick={() => setTab(activeTab + 1)}>Next →</button></>}
        <button className="btn" onClick={tryClose} disabled={busy}>Cancel</button>
        {!row && <button className="btn" onClick={() => void submit(true)} disabled={busy}>Save &amp; add another</button>}
        <button className="btn primary" onClick={() => void submit()} disabled={busy || (!!row && !dirty)}>{busy ? 'Saving…' : row ? 'Save changes' : 'Create item'}</button>
      </div>

      {leave && (
        <Modal title="Discard changes" onClose={() => setLeave(false)}>
          <h2 style={{ marginBottom: 8 }}>Discard your changes?</h2><p className="muted">Everything you typed will be lost.</p>
          <div className="row" style={{ justifyContent: 'flex-end' }}><button className="btn" onClick={() => setLeave(false)}>Keep editing</button><button className="btn primary" style={{ background: 'var(--bad)' }} onClick={discard}>Discard</button></div>
        </Modal>
      )}
    </Modal>
  )
}

function Field({ f, v, set, err, engine }: { f: SpField; v: Val; set: (v: Val) => void; err?: string; engine: Engine }) {
  const id = `f-${f.internal}`
  const common = { id, 'aria-invalid': !!err, 'aria-describedby': err ? `${id}-e` : undefined }
  const wide = f.kind === 'note' || f.kind === 'user' || f.kind === 'multichoice' || f.kind === 'url' || f.internal === 'Title' || f.internal === 'FileLeafRef' || (f.kind === 'choice' && (f.choices?.length ?? 0) <= 6)
  let control: ReactNode
  switch (f.kind) {
    case 'note': control = <><textarea {...common} className="input" rows={5} value={v as string} onChange={(e) => set(e.target.value)} style={{ resize: 'vertical' }} /><span className="muted small" style={{ textAlign: 'right' }}>{(v as string).length.toLocaleString()} characters</span></>; break
    case 'choice': {
      const ch = f.choices ?? []
      control = ch.length && ch.length <= 6
        ? <div role="radiogroup" aria-label={f.title} className="chipset">{ch.map((c) => <button type="button" key={c} role="radio" aria-checked={v === c} className="chipbtn" style={{ ['--tc' as string]: hashColor(c) }} onClick={() => set(v === c ? '' : c)}><i aria-hidden="true" />{c}</button>)}</div>
        : <select {...common} className="input" value={v as string} onChange={(e) => set(e.target.value)}><option value="">—</option>{ch.map((c) => <option key={c}>{c}</option>)}</select>
      break
    }
    case 'multichoice': control = <div role="group" aria-label={f.title} className="chipset">{(f.choices ?? []).map((c) => { const on = (v as string[]).includes(c); return <button type="button" key={c} role="checkbox" aria-checked={on} className="chipbtn" style={{ ['--tc' as string]: hashColor(c) }} onClick={() => set(on ? (v as string[]).filter((x) => x !== c) : [...(v as string[]), c])}><i aria-hidden="true" />{c}</button> })}</div>; break
    case 'boolean': control = <button type="button" role="switch" aria-checked={v === 'true'} aria-label={f.title} className="switch" onClick={() => set(v === 'true' ? 'false' : 'true')}><span /><b>{v === 'true' ? 'Yes' : v === 'false' ? 'No' : 'Not set'}</b></button>; break
    case 'date': control = <div className="row" style={{ gap: 6 }}><input {...common} className="input" type="date" value={v as string} onChange={(e) => set(e.target.value)} />{[['Today', 0], ['Tomorrow', 1], ['+1 wk', 7]].map(([l, d]) => <button type="button" key={String(l)} className="btn sm" onClick={() => set(iso(new Date(Date.now() + Number(d) * 86_400_000)))}>{l}</button>)}{v && <button type="button" className="btn sm ghost" onClick={() => set('')}>Clear</button>}</div>; break
    case 'number': case 'currency': control = <div className="row" style={{ gap: 4, flexWrap: 'nowrap' }}>{f.kind === 'currency' && <span className="muted">$</span>}<input {...common} className="input" inputMode="decimal" value={v as string} onChange={(e) => set(e.target.value)} style={{ flex: 1 }} />
      <button type="button" className="btn sm" aria-label={`Decrease ${f.title}`} onClick={() => set(String((Number(v) || 0) - 1))}>−</button><button type="button" className="btn sm" aria-label={`Increase ${f.title}`} onClick={() => set(String((Number(v) || 0) + 1))}>+</button></div>; break
    case 'user': {
      const list = v as Principal[]
      control = <div><div className="row" style={{ gap: 6, marginBottom: list.length ? 6 : 0 }}>{list.map((p, i) => <span key={p.title + i} className="chip"><span className="av" style={{ ['--tc' as string]: hashColor(p.title) }} aria-hidden="true">{initials(p.title)}</span>{p.title}<button type="button" aria-label={`Remove ${p.title}`} onClick={() => set(list.filter((_, j) => j !== i))}><Icon n="x" size={12} /></button></span>)}</div>
        {(f.multi || !list.length) && <PrincipalPicker backend={engine.backend} src={engine.src} onPick={(p) => set(f.multi ? [...list, p] : [p])} />}</div>
      break
    }
    case 'url': { const u = v as { url: string; desc: string }; control = <div className="row" style={{ gap: 6 }}><input {...common} className="input" placeholder="https://…" value={u.url} onChange={(e) => set({ ...u, url: e.target.value })} style={{ flex: 2, minWidth: 160 }} /><input className="input" aria-label={`${f.title} description`} placeholder="Display text" value={u.desc} onChange={(e) => set({ ...u, desc: e.target.value })} style={{ flex: 1, minWidth: 100 }} /></div>; break }
    default: control = <input {...common} className="input" value={v as string} onChange={(e) => set(e.target.value)} autoFocus={f.internal === 'Title' && false} />
  }
  return (
    <div className={`ip-field${wide ? ' wide' : ''}`}>
      <label className="ip-label" htmlFor={f.kind === 'choice' || f.kind === 'multichoice' || f.kind === 'boolean' || f.kind === 'user' ? undefined : id}>{f.title}{f.required && <span aria-hidden="true" style={{ color: 'var(--bad)' }}> *</span>}</label>
      {control}
      {err && <span id={`${id}-e`} role="alert" className="ip-err">⚠ {err}</span>}
    </div>
  )
}

/* ---------------------------------------------------------------- tab names that describe the columns inside */
const THEMES: [string, string, (f: SpField) => boolean][] = [
  ['Contact details', '✉', (f) => /e-?mail|phone|mobile|fax|address|street|postal|zip|contact|website|linkedin|twitter/i.test(f.title + f.internal) || (f.kind === 'url' && !/photo|image/i.test(f.title))],
  ['Pay & budget', '＄', (f) => f.kind === 'currency' || /\b(salary|budget|cost|price|amount|revenue|fee|bonus|spend|invoice|compensation|wage|rate)\b/i.test(f.title + f.internal)],
  ['Schedule & dates', '◷', (f) => f.kind === 'date'],
  ['People & roles', '☺', (f) => f.kind === 'user' || /manager|owner|buddy|assignee|supervisor|approver|mentor|sponsor/i.test(f.title)],
  ['Location & workspace', '⌖', (f) => /\b(location|office|building|room|desk|floor|city|country|region|site|campus|seat)\b/i.test(f.title + f.internal)],
  ['Equipment & access', '▣', (f) => /\b(laptop|badge|equipment|device|asset|license|licence|software|monitor|keyboard|headset|dock|access|vpn|tool)s?\b/i.test(f.title + f.internal) || f.kind === 'multichoice'],
  ['Status & progress', '◈', (f) => /\b(status|stage|priority|risk|progress|percent|complete|training|approval|phase|state|outcome|health)\b/i.test(f.title + f.internal) || f.kind === 'boolean'],
  ['Notes & links', '✎', (f) => f.kind === 'note' || f.kind === 'url'],
]
const MAX_TAB = 9
const names = (fs: SpField[], n = 2) => { const t = fs.slice(0, n).map((f) => f.title); const extra = fs.length - t.length; return `${t.join(' & ')}${extra > 0 ? ` +${extra}` : ''}` }
const clip = (s: string, n = 30) => (s.length > n ? s.slice(0, n - 1) + '…' : s)

/** Groups the form's columns into tabs whose names say what is inside (Contact details, Pay & budget, Schedule & dates…). */
export function buildTabs(fields: SpField[]): { id: string; title: string; icon: string; hint: string; fields: SpField[] }[] {
  const used = new Set<string>()
  const take = (fs: SpField[]) => fs.filter((f) => !used.has(f.internal) && (used.add(f.internal), true))
  const out: { id: string; title: string; icon: string; hint: string; fields: SpField[] }[] = []
  const add = (title: string, icon: string, fs: SpField[]) => {
    if (!fs.length) return
    const parts = Math.ceil(fs.length / MAX_TAB)
    for (let i = 0; i < parts; i++) {
      const chunk = fs.slice(i * MAX_TAB, (i + 1) * MAX_TAB)
      out.push({ id: `${title}-${i}`, title: parts > 1 ? `${title} ${i + 1}/${parts}` : title, icon, hint: chunk.map((f) => f.title).join(', '), fields: chunk })
    }
  }
  const basics = take(fields.filter((f) => f.internal === 'Title' || f.internal === 'FileLeafRef' || f.required))
  const themedAll = THEMES.map(([name, icon, test]) => [name, icon, fields.filter((f) => !used.has(f.internal) && test(f))] as const)
  // a theme only becomes a tab when it holds at least two columns; a lone column joins the 'other' tab, which is named after its own columns
  const themed: (readonly [string, string, SpField[]])[] = []
  for (const [name, icon, fs] of themedAll) { const free = fs.filter((f) => !used.has(f.internal)); if (free.length >= 2) themed.push([name, icon, take(free)]) }
  const rest = take(fields)
  // the first tab is named after the columns that must be filled in, e.g. "Employee name & Job title"
  if (basics.length) add(basics.length > 3 ? 'Required details' : clip(names(basics, 2)), '✦', basics)
  for (const [name, icon, fs] of themed) add(name, icon, fs)
  // anything unclassified is named after its own columns, e.g. "Desk number & Probation end"
  if (rest.length) { for (let i = 0; i < rest.length; i += MAX_TAB) { const chunk = rest.slice(i, i + MAX_TAB); out.push({ id: `rest-${i}`, title: clip(names(chunk, 2)), icon: '◇', hint: chunk.map((f) => f.title).join(', '), fields: chunk }) } }
  return out
}
