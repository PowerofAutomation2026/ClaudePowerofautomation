"""Azure Terraform MCP - governed Terraform for agents, running natively on Azure."""

__version__ = "2.0.0"
