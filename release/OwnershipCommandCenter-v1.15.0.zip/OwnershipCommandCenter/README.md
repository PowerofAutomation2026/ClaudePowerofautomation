# Ownership Command Center

A Power Apps **code app** (React + TypeScript) for Power Platform admins:
enter a user's email → see every canvas/model app and cloud flow they own **across all environments** →
transfer ownership of selected items, or everything, to a new owner.

**No Azure app registration.** It runs on the signed-in admin's own connector connections:
Power Apps for Admins, Power Platform for Admins, Power Automate Management (+ optional Power Automate for Admins), Office 365 Users.

## Deploy (zero touch)

```powershell
./scripts/Deploy-OwnershipCommandCenter.ps1                 # prompts for environment ID
./scripts/Deploy-OwnershipCommandCenter.ps1 -EnvironmentId <guid>
```
It installs Node/`pac` if missing, signs you in, wires the three connectors (opens the Connections page if one is missing), builds and runs `pac code push`.

Requirements: Power Apps premium licence for the admin users (code apps + premium connectors) and code apps enabled on the target environment.

## Features
- Email → user → inventory across all (or one) environment, with scan progress and recent-user chips
- Stats dashboard, per-environment bars (click to filter), search / type / state filters, sorting
- Select individual rows, all visible, all apps, all flows, or stale items (>6 months) — or transfer everything
- **Replace owner** or **add as co-owner** (flows), optionally remove previous owner
- **Dry run** (default on), typed confirmation for big batches, per-item status, **retry failed**, **undo last batch**
- Risk flags: solution-aware items, flows with connections tied to the old owner, stopped/suspended flows
- **Generate the equivalent PowerShell** for change tickets
- Audit history (CSV export), inventory export (CSV/JSON)
- Dark/light theme, Ctrl+K command palette, `/` to focus search, Demo mode with a sample tenant

## Develop
```bash
npm install
npm run dev      # Demo mode in the browser
npm run build
```

## Fallback without the UI (still no app registration)
In the transfer panel click **⬇ Plan CSV** (put the new owner's *object id* in `NewOwnerId`), then run
`./scripts/Invoke-OwnershipPlan.ps1 -PlanCsv plan.csv -WhatIf` and again without `-WhatIf`. It uses Microsoft's own admin
module with interactive sign-in.

## Important: verify the connector bindings
The app calls connectors through the code-apps SDK (`getClient().executeAsync`) using the operations in the generated
`.power/schemas/appschemas/dataSourcesInfo.ts`. `src/services/live.ts` finds each operation by its REST path and verb
(e.g. `POST …/modifyAppOwner`), so generated method names don't matter. After deploying, open **🩺 Diagnostics**:
every operation should say *bound*. If one is missing, adjust its path pattern in `OPS`. This could not be tested
against a live tenant while building, so treat the first Live run as a pilot: use **Dry run**, then try one item.

Notes: Power Apps have a single owner (co-owner mode applies to flows only). Solution flows may need their
connection references re-pointed after transfer.

## Connectors needed (create each once in the target environment)
| Connector | Id | Used for |
|---|---|---|
| Power Apps for Admins | `shared_powerappsforadmins` | list apps, change app owner |
| Power Platform for Admins | `shared_powerplatformforadmins` | list all environments |
| Power Automate Management | `shared_flowmanagement` | list flows, change flow owner as admin |
| Office 365 Users | `shared_office365users` | email → user object id |
| Power Automate for Admins *(optional)* | `shared_microsoftflowforadmins` | flow list with creator, flow owner lookups |
| Power Platform for Admins V2 | `shared_powerplatformadminv2` | **Copilot Studio agents**: tenant-wide inventory query + *Reassign the owner of the bot* |

## Troubleshooting
* **"Connector operation … not found"** → open 🩺 Diagnostics, click *Copy diagnostics*; each connector's real operations are listed.
  Re-run the deploy script to add the missing connector, then redeploy.
* Re-running the script on an existing folder reuses `power.config.json` (same app, updated in place). Extract new versions *over* the old folder.
* **Build fails inside `src/generated/...` (e.g. `api-version?: string`)** → a `pac` code-generation bug; the app doesn't use `src/generated`
  (it reads `.power/schemas/appschemas/dataSourcesInfo.ts`). `tsconfig.json` excludes that folder and the deploy script falls back to a plain `vite build`.
* **`ApplicationDisplayNameIsInUse` on publish** → `power.config.json` was lost/recreated. The deploy script now binds to the existing app automatically
  (sets `appId` in `power.config.json`) and updates it in place. Keep `power.config.json` between runs.
* **`power.config.json is required to push an app`** → the file was missing/unreadable (a UTF-8 BOM from Windows PowerShell breaks `pac`). The deploy script
  now edits it without a BOM, keeps a copy in `.deploy-state/`, restores it if `pac` removes it, and as a last resort publishes under a new dated name.
* **`InvalidApiVersion`** → the connectors list `api-version` as optional but the service requires it. The app always sends it and, if rejected, reads the accepted versions from the error and retries.

## Copilot Studio agents (experimental)
**This app's own environment** is read through the app's built-in Dataverse access: the deploy script runs `pac code add-data-source -a dataverse -t bot` and `-t systemuser`
(no extra connection). **Other environments** need the optional *Microsoft Dataverse (legacy)* connector.
Agents are Dataverse `bot` rows. With the optional *Microsoft Dataverse (legacy)* connector the app finds the user's Dataverse record in each
environment that has a database, lists `bots` owned by them and transfers ownership with `ownerid@odata.bind`. The new owner must already be a user in
that environment. Agents have a single owner. Verify with a dry run, then one agent, first.

## Scan report
After every scan the *Scan report* card lists, per environment, how many apps / flows / agents were listed and how many belong to the user, plus any
warnings (for example "not an admin in this environment"). Use *Copy* to share it when something looks missing.

* **Browser tab crashes with "Out of Memory"** → fixed in v1.3.0: one SDK client for the whole session, environments scanned one at a time, owner lookups
  capped (400 flows/environment) and limited to 4 at once. If it still happens, scan one environment at a time (pick it in the dropdown) and close other tabs.

* **Crash breadcrumb** → if a tab dies, the next load shows "Last time this page stopped unexpectedly while …" naming the environment/phase it was scanning.
* Large environments are read page by page (max 10 pages / 20,000 items per list) and the report tells you if a list was cut off.
* **Agents show 0 although the Dataverse tables were added** → `pac` names the data sources by display name (`agents`, `users`); v1.4.1 identifies them by primary key / entity set instead. 🩺 shows which data source each table mapped to.
* **Transfer "does nothing"** → the new owner's email must be entered first. v1.5.0 explains this inline, accepts Enter, and shows the result (dry-run or real) in the drawer.
* **Agents in other environments** → agents are read from the environment the app is deployed in. Run the deploy script again with that environment's ID (state is kept per environment in `.deploy-state/<envId>`).

## Copilot Studio agents (v1.6.0 – tenant-wide)
Discovery uses the **Power Platform inventory** (action *Query Power Platform resources*, type `microsoft.copilotstudio/agents`, property `ownerId`) so agents in **every environment**
show up from one deployment. Transfer uses *Reassign the owner of the bot* (`ReassignCopilotAgent`, body `NewOwnerAadUserId`).
Requirements: the connection's account must be a tenant/Power Platform admin and hold **System Administrator** in the agent's environment; the new owner needs the
**System Customizer** role there (temporarily) and a Microsoft 365 Copilot licence. Classic chatbots are not supported by the reassign API (HTTP 405).
If discovery shows 0, open the Scan report: it prints the owner ids it saw so the id format can be compared.

## v1.7.0 – only real Copilot Studio agents + new look
* The tenant inventory type `microsoft.copilotstudio/agents` also contains Agent Builder agents, CLI-harness agents and tool / MCP style entries. Every item is
  classified (`agent`, `agentbuilder`, `tool`, `mcp`, `cli`, `other`) from its inventory properties. **Only `agent` is shown and transferable by default**; the rest are
  counted in a banner ("N other inventory items are hidden") with a *Show them* toggle. The Scan report prints the classification counts and the property values it saw,
  so the rules can be tuned from real data.
* New interface: animated aurora background, profile hero with type-mix bar (blue = apps, orange = flows, aqua = agents – validated colour slots 1-3 with direct labels),
  icon stat tiles with count-up, tabs with counts, type chips, status dots, shimmer skeleton while scanning. Dark and light themes.

## v1.7.1 – agent transfer failures
* A failed transfer no longer clears the item list: the error stays on screen (full service text, HTTP status) with a plain-language "Why this usually fails" box and **Retry**.
* Agent transfer first calls *Reassign the owner of the bot*; if that fails and the agent lives in the app's own environment it falls back to a Dataverse assign.
* Known causes (Microsoft docs / community): the **new owner needs the System Customizer role** in the agent's environment (temporarily) and a Microsoft 365 Copilot licence;
  the connection account needs System Administrator there; **managed-solution** agents can be blocked (make an unmanaged edit or use the admin center *Change owner*);
  **classic chatbots** return HTTP 405.

## v1.7.2 – "HTTP 502 … only partially updated" when transferring an agent
That is the Copilot Studio reassign API refusing to finish. Documented cause: the **new owner lacks the System Customizer security role in the agent's environment**
(or isn't a user there / has no licence). The connector only shows a generic *"The response is not in a JSON format"*; the real reason is in `innerError`, which the app now shows.
1. Admin center → Environments → *(agent's environment)* → Users → new owner → Manage security roles → tick **System Customizer** → Save (wait 1-2 min).
2. Click **Retry** in the transfer panel. If a failed attempt left the agent half-updated, **↩ Restore original owner** puts it back.

## v1.7.3 – transferring an agent WITHOUT System Customizer
Microsoft's documented requirements for the new owner of a reassigned agent are only: a **Copilot Studio / Microsoft 365 Copilot licence** and **membership of the agent's environment**; the service
then grants *Environment Maker* itself. (System Customizer appears only in a community fix, most likely because adding any role creates the environment user record.)
* Add the new owner as a **member** of the environment first (admin center → Environments → *env* → Users → Add user, lowest role), wait 1-2 min, transfer.
* The app now asks you to confirm the checklist before a real agent transfer, and for agents in the app's own environment it **checks the new owner's user record first** and stops *before* calling the service (no half-updated agents).
* Only if it still fails: temporarily add System Customizer, retry, remove.

## v1.7.4 – built-in "add new owner to the environment" step (no roles)
Before a real agent transfer the app calls the Power Platform for Admins operation **Add Admin Power Apps Sync User** for each agent environment, which makes the new owner a
member (Dataverse user record) of that environment without assigning any security role – Microsoft's documented requirement for a reassign. Untick it in the panel to skip. If it fails
(for example the connection account lacks rights) the error is shown and the transfer still proceeds. Wait ~1 min and Retry if the reassign reports "partially updated".

## v1.7.5 – recovering agents left half-updated
* **History → "↩ Restore to <original owner>"** appears on every failed agent transfer and works after a page reload (the audit log is kept in the browser).
* Re-running a reassignment for the **same owner** is allowed for agents (repair mode): scan the new owner, select the agent, enter the same email, transfer.
* Failure tips now include the discriminating test (same agent → a different fully licensed user) and verification (open the agent in Copilot Studio as its owner).

## v1.7.6
Agent reassign retries once automatically (after 8 s) when the service answers HTTP 502 / "partially updated" – Microsoft's own error text says another reassignment is the repair.
Advisor findings (see chat): the most likely cause is the **new owner has no Copilot Studio licence / no enabled environment user**; check licence and sign-in first, or reassign to a healthy licensed admin.

## v1.8.0 – safe agent transfer protocol (no more corrupted agents from a batch)
Found by code review + an independent advisor review + a simulated Copilot Studio service (9 scenarios, `src/transferPlan.ts`):
* **Pilot / stop-on-first-failure:** agents are reassigned strictly one at a time; the first service failure STOPS the batch (remaining agents are `skipped`, untouched). Before, 3 parallel workers kept going and one click could half-update every selected agent.
* **Membership gate:** the new owner is added to each environment (Add Admin Power Apps Sync User) and, where checkable, confirmed; any failure blocks that environment's agents ("Not attempted – nothing was changed"). "user does not exist" is no longer mistaken for "already a member".
* **No automatic retry, no Dataverse fallback after a failed reassign** (both could worsen/hide a half-updated agent). Retry is manual, after fixing the cause.
* **Only real Copilot Studio agents** can be sent to the reassign API; tool / MCP / Agent Builder / CLI rows are refused. Classification no longer looks at display names.
* **Verification:** after a successful reassign the inventory is queried; the result is shown per agent (inventory may lag 5–15 min).
* **Restore / Undo** are audited, appear only for genuine "partially updated" failures, stop at the first failure, and use the options of the original batch.
Residual risk: the app cannot read licences. An unlicensed new owner can still half-update the *first* (pilot) agent – check the licence first; use History → Restore if it happens.

## v1.9.0 – "moved" now means CONFIRMED at the source
Audit result: every transfer is a real server-side admin API call (agents: `ReassignCopilotAgent`; apps: `Set-AdminAppOwner`; flows: `modifyPermissions` Owner role). The UI never changes ownership by itself.
But "success" used to mean only "the service answered 2xx". Now, after each transfer the owner is **read back from the source** (agents: Dataverse `bot.ownerid` in the app's own environment, otherwise the tenant inventory, re-read after 12 s;
apps: Get Admin App; flows: owner roles) and each row shows **Verified at the source** or **⚠ NOT confirmed**. Only confirmed rows leave the table; unconfirmed rows stay with a **🔄 Re-check at the source** button.
* Flows keep an immutable *creator*; a rescan now also checks the Owner role, so a transferred flow is no longer listed under the old owner.
* Membership settle time before an agent reassign raised from 4 s to 8 s.
* Where to look as the new owner: Copilot Studio → pick the SAME environment as the agent (e.g. *microsoft (default)*) → Agents. Admin center / inventory can lag 5–15 min.

## v1.9.1 – live agent count (deleted agents no longer listed)
The tenant inventory keeps showing deleted agents for a while. After the inventory read, every agent is now checked against the Dataverse `bot` table of its own environment: deleted agents and agents whose owner already changed are dropped, name/state are refreshed. The Scan report says how many were confirmed, how many deleted ones were removed, and how many could not be live-checked (environments this app cannot reach).

## v1.9.2 – accurate live agents, real operation log, auto-refresh
- **CLI / GitHub-Copilot-powered agents** (e.g. `copilotowner26`, `TESTOWNERTRANSFER`) are real Copilot Studio agents and are now listed (tagged "GitHub Copilot") instead of hidden.
- **Live check**: agents are confirmed against Dataverse; rows show `✓ live` or `⚠ not live-checked`. The inventory can still list DELETED agents, so for the exact count deploy the app into the agents' environment (e.g. `-EnvironmentId Default-<tenantId>`) or add the optional Microsoft Dataverse connector (the deploy script now offers it).
- **Agent pre-flight**: before reassigning, the agent must still exist in Dataverse, otherwise nothing is sent.
- **Operation log** (Transfer drawer and Diagnostics): every connector call, pre-flight, transfer, read-back result with timestamps; Copy log button.
- **Auto-refresh**: 5 s after a real transfer the user is re-scanned so the table shows live data.

## v1.9.4 – a failed agent transfer never takes the agent from the original user
- When the reassign fails half-way (HTTP 502 "partially updated") the app first READS the owner at the source: if the new owner is already confirmed it says so; if the original owner is still confirmed it says "nothing changed"; only otherwise it reassigns back to the original owner automatically (one attempt) and reads back again. The batch still stops at the first failure.
- New pre-flight: a disabled or non-interactive target user in the agent's environment blocks the transfer before anything is sent (environment this app runs in).
- If it still fails with the target a licensed environment member, the usual cause is the target's Copilot Studio licence/service plan - test by signing in as that user in Copilot Studio.

## v1.9.5 – licence-first guidance for the agent 502
Microsoft: agent ownership can only be reassigned to a user with an ACTIVE Microsoft 365 Copilot licence. If a transfer returns 502 "partially updated" while the target is an environment member and the app shows "Nothing changed … still the owner (CONFIRMED)", assign the licence to the target in the Microsoft 365 admin center, wait ~10 minutes, and retry. The pre-flight now says honestly when the target's user status could not be checked.

## v1.9.6 – live agents from Dataverse (any environment), no more false "nothing changed"
- The tenant inventory lags BOTH ways (transferred/deleted agents linger, new agents missing). Agents are now reconciled against Dataverse of each environment: this app's own environment natively, every other environment through the Microsoft Dataverse connector (added by the deploy script). Agents that exist in Dataverse but not yet in the inventory are added; deleted / already-moved ones are removed. Rows show `✓ live`.
- Read-backs (after a transfer) use the same Dataverse source. An inventory mismatch is never treated as proof of "nothing changed", and the automatic rollback only runs when Dataverse itself shows the agent is neither with the new nor the original owner.
- New: `↗ open` link on every row (opens the item in its own portal to check the Owner column) and `⬇ Download receipt` (the full operation log as a text file).
- Observed in a real tenant: a 502 "partially updated" can still end with the agent owned by the new user - always check the Owner column in Copilot Studio.

## v1.9.7 – transfer a whole solution
`📦 Solutions` (also Ctrl K → "Transfer a whole solution") lists the solutions that contain the scanned user's apps, cloud flows and Copilot Studio agents (read through the Microsoft Dataverse connector). Pick one to select all of that user's items in it, then transfer them with the normal verified pipeline (dry run, read-back, rollback protection).
Limits (by design): a solution itself has no owner; tables, security roles, plug-ins, model-driven apps are organisation-owned; classic workflows / connection references / environment variable values are not moved by this app; flows keep the OLD owner's connections until the new owner re-binds them; managed solutions may block some changes.

## v1.9.8 – Report studio (CSV + PDF)
`📄 Report` (or Ctrl K → "Report") opens a report for the scanned user: choose apps / flows / agents (or only the selected items), preview, then download a CSV (UTF-8 with BOM, opens in Excel) or a PDF (built in the browser, no libraries). Columns: type, name, id, created time, environment name, environment id, owner, state.

## v1.9.9 – new agents appear immediately, multi-user PDF report, agent 502 polling
- **Live source**: 🩺 Diagnostics now has a real "Live Dataverse test" per environment (✔ = agents are read live there, so a brand-new agent shows up on the next scan). If the live source is unavailable for some environments the main screen shows an amber banner with "↻ Re-scan now" instead of silently listing a stale inventory.
- **Agent transfer**: when the service answers 502 "partially updated", the app now polls the REAL owner for ~50 s (Copilot Studio often finishes the change after answering with an error) before deciding; only then does the read-before-rollback logic run.
- **Report studio**: add more users (emails, comma/space/new line); each is scanned across all environments; one CSV (all rows, Owner column) and one PDF with a section per user. Filter apps / flows / agents with the three count buttons.

## v1.9.10 – make the live Dataverse source reachable for other environments
- The environment list often omits each environment's Dataverse address, which silently disabled the live agent check outside the app's own environment. Missing addresses are now read per environment (and `$expand=properties.linkedEnvironmentMetadata` is requested when supported).
- The Dataverse connector is called with the organisation as `host` and, if that fails, as `https://host` (the working form is remembered).
- Transfer drawer: every item has a link to check its Owner in its own portal.
- **Most reliable setup**: deploy the app INTO the environment that holds the agents (`-EnvironmentId e6c360d6-57a5-473e-9188-3bfac0e3250e` for "microsoft (default)"). There the app reads and verifies agents natively, with no connector guesswork.

## v1.9.11 – Dataverse connector call matches Microsoft's own parameters
Cross-environment reads use `ListRecordsWithOrganization` with `organization = https://orgXXXX.crm.dynamics.com`, `entityName`, `$filter/$select/$top` and `accept` (found in public code-app samples). Parameters are matched by meaning, wherever the connector places them; the plain hostname is tried as a fallback.

## v1.9.12 – cloud flow transfer fix
The flow permission API rejected `roleName: "Owner"` (HTTP 400: accepted values are CanEdit, CanViewWithShare, CanView). Flows are now transferred by adding the new user as a **CanEdit co-owner** (what Power Automate shows as an owner); "Replace" then tries to remove the previous owner in a second call and reports honestly if Power Automate refuses (the creator stays recorded on the flow). Scan and read-back treat `Owner` (creator) and `CanEdit` (co-owner) as owners.

## v1.9.13 – flow "replace owner" removes the previous owner correctly
The previous owner is removed by ROLE id (looked up from the flow's owner list) after the new CanEdit owner was added first. Solution-aware flows are also owned in Dataverse; that record owner is not changed by this step.

## v1.10.0 – enterprise pack: email reports, schedules, notifications
Based on what admins ask for most (offboarding checklists, bulk reassign, orphan detection, telling the right people):
- **✉ Email this report** (📄 Report): recipients + CSV/PDF attachments + an HTML summary, sent from the signed-in admin's own mailbox through the **Office 365 Outlook** connector (the deploy script adds it as an optional connector; approve it on first launch).
- **⏰ Schedules**: save report definitions (users, apps/flows/agents, recipients, daily / weekly / monthly at an hour). They run **while the app is open** and catch up when it is opened after a missed run ("Run now" any time). A code app has no server, so nothing runs when nobody has it open.
- **✉ Email the new owner** (and optionally the previous owner's manager, looked up in Office 365 Users) after a transfer, with a per-item result table.

### Unattended reports (fully automatic, nobody has the app open)
Use a scheduled Power Automate cloud flow owned by an admin or service account (premium licence for the admin connectors):
1. Power Automate → Create → **Scheduled cloud flow** (e.g. weekly Monday 08:00).
2. Add **Power Apps for Admins - Get Apps as Admin** (per environment), **Power Automate Management - List Flows as Admin**, filter by the user's id, and **Create CSV table**.
3. Add **Office 365 Outlook - Send an email (V2)** with the CSV as attachment.
4. Put the flow in a solution with connection references so it can be reassigned later (this app can do that).

## v1.10.2 – more complete scans (apps, flows, all kinds of agents) in every environment
Based on the connector schemas and Microsoft's inventory docs:
- **Cloud flows**: the admin flow-list operations expose `$top` but no continuation parameter, so the scan now asks for pages of 250 (falls back if rejected) and tries `$skiptoken` anyway, stopping safely when a page adds nothing. If the first list operation returns nothing the next one is tried. The V2 list has no creator, so owners are looked up per flow (up to 400 per environment). In environments with Dataverse, `workflow` rows (category 5) owned by the user are cross-checked and any solution flow the list missed is added. (Flows in "My flows" exist only in the flow service, so only the admin API can see them.)
- **Apps**: canvas apps from the admin list plus **code apps** found through the tenant inventory (tagged "Code app").
- **Agents**: Copilot Studio agents, GitHub-Copilot-powered agents and **Agent Builder** agents are shown by default (tools / MCP / other stay behind the toggle). Only classic Copilot Studio agents are checked against the Dataverse `bot` table; Agent Builder agents are shown as the inventory reports them.
- The Scan report ends with "Per environment (apps / flows / agents)" so you can compare each environment with its portal.

## v1.11.0 – agent flows and Copilot Studio "Workflows"
Copilot Studio's **Workflows** page lists "workflow agent flows" (`microsoft.powerautomate/m365agentflows`); "agent flows" are `microsoft.powerautomate/agentflows`. Both are cloud flows with a Dataverse `workflow` row (`workflowEntityId`). The scan now reads them from the tenant inventory in every environment, shows them in the **Flows** tab with an "Agent flow" / "Workflow" tag and tags matching flows already found by the flow list.
Transfer: the new owner is added as a CanEdit co-owner through the flow API **and**, for Dataverse-backed flows (solution, agent, workflow), the Dataverse `workflow` owner is set to the new owner through the Microsoft Dataverse connector (update row). The read-back confirms through the flow owner list or the Dataverse owner, whichever shows the new owner. If one route is refused the row says which one worked.

## v1.12.0 – 🔐 Exposure Auditor (cyber-security: who can reach what)
New view (header button **🔐 Exposure Auditor**, or Ctrl K). Tenant-wide audit of *sharing exposure* across all environments, with **no app registration** and **no new connectors** (reuses Power Apps for Admins, Power Automate Management, Office 365 Users; optionally the *connections as admin* operations).
Picked after a research pass because Microsoft only documents manual PowerShell/CoE-kit workarounds for flows shared outside an environment, and its Security Hub sharing recommendation covers apps only (Managed Environments only, active in the last 90 days only). There is no first-party report for connection-credential sharing.

| Finding | Severity | How it is computed |
|---|---|---|
| Shared with **everyone** (app/flow) | High | permission principal is the tenant (`type=Tenant`, `tenant-…` id) |
| Shared with a **guest / external** account | High | principal UPN contains `#EXT#` |
| **Connection credentials shared** | High (share/edit roles) / Medium | connection role assignments other than its creator |
| Connection owned by a **disabled/deleted** user | High | creator → Office 365 Users profile (`accountEnabled=false` or 404) |
| **Too many editors** (> N, or any group with CanEdit) | Medium | app role assignments |
| **Too many flow co-owners** (> 3) | Medium | flow owner roles |
| Connection in **error** state | Low | `statuses[].status` |
| Permissions **unreadable** / list says more shares than were read | Info | never reported as "safe" |

Screens: scan with progress + per-environment Scan report (counts of successful permission reads), exposure score, severity/type filters, CSV export, **PowerShell export**, 🩺 operation binding. Remediation: select findings → **Remove selected shares** (apps and flows) with **Dry run on by default**, typed confirmation above 5 items, stop at the first failure, and a **read-back** check that the share is really gone. Connection shares are report-only.
Code: `src/exposure/` (`rules.ts` pure rule engine, `live.ts` connector scanner, `demo.ts` sample tenant, `ExposureView.tsx`).

**Limits (cannot be done without an app registration):** expanding group membership, Entra sign-in activity, the sharing audit log (Purview). Groups are reported as one principal.
**Unverified against a live tenant** – treat the first Live run as a pilot: (1) how "Everyone" is encoded (`type: Tenant` assumed), (2) the exact connector operations for app role assignments / connections / connection role assignments are bound by path pattern – check 🩺 and adjust `EX` in `src/exposure/live.ts`, (3) some admin connectors may omit `sharedUsersCount` or return permissions only for tenant admins – an empty result with failed reads is flagged in the Scan report, (4) per-resource permission reads are capped at 400 per environment and kind, 4 in parallel.
Roadmap: HTTP-action egress to non-allow-listed hosts, flow run-only users, scheduled emailed exposure report, DLP what-if.

## v1.13.0 – 🕸️ Credential Blast-Radius Map (new)
Header button **🕸️ Blast-Radius Map** (or Ctrl K). Builds one graph of **user → flow/app → connection → data surface** from the Exposure Auditor scan and answers, for any account:
* **💥 If compromised** – every credential (connection) the account can act *through*, transitively, with the path and a blast-radius score (connector sensitivity × path strength, ×1.5 when the credential's owner is disabled).
* **🎭 Who can act as them** – reverse walk: every account that can reach this person's stored credentials.
* **🚪 Offboarding** – what stops working if they are disabled, which of their credentials others can still use with nobody watching, and which flows/apps only they can edit.
* Global findings: privileged credential reachable by others (`PRIV_REACH`), **escalation chain through a control-plane credential** (`CHAIN`), guest/everyone reach, disabled owner's credential still powering automation, credential fan-out, unresolved group.
Chains continue only through *control-plane* connectors (Power Platform / Power Automate admin, Entra, Dataverse, HTTP…) because those credentials can grant themselves more access; every other connector (Outlook, SharePoint, SQL…) is a leaf ("reaches that data"). Flow connections set to *run-only user's own* (source `Invoker`) are not the owner's credentials and create no edge.
Why it's different: Microsoft Security Hub, CoE Kit, Rencore and Syskit list ownership/sharing; none computes transitive credential reachability. Closest is SpecterOps BloodHound's Entra-agent preview (enterprise product, agent-centred, needs collectors + a Graph app registration). This runs in your tenant on your admin's connections.
Code: `src/blast/graph.ts` (pure engine, unit-testable), `src/blast/BlastView.tsx`; the scan (`src/exposure/live.ts`) now also reads each flow's/app's connection references (capped 300 per environment).
**Limits / unverified:** group membership, Entra roles, sign-in activity and the real permissions a credential has at the data source are unknown (reach = upper bound, never "safe"); the per-flow *Get flow as admin* and per-app read must be bound (🩺 on the Exposure Auditor lists them); solution flows may reference connection *references* rather than connections (those edges are missing until the Dataverse join is added). Defensive use only: audit, offboarding, least privilege.

## v1.14.0 – 📡 Egress Radar (new): where does every flow send your data?
Header button **📡 Egress Radar** (or Ctrl K); the four modules are linked by a shared navigation bar.
**Why:** the same gap appears throughout Microsoft's own docs and practitioner write-ups – an admin can see *that* a flow makes an HTTP call but not *where it goes*; DLP cannot catch HTTP actions / custom connectors; Microsoft's published script (`Get-AdminFlowWithHttpAction`) lists flows with HTTP actions but not their destinations. No built-in end-to-end destination report was found.
It reads every flow definition (*Get Flow as Admin*, with the definition) and walks all actions (scopes, conditions, loops, switches) to list **every destination host**:

| Finding | Severity |
|---|---|
| Sends to a capture / paste / tunnel service (webhook.site, requestbin, pipedream, ngrok, pastebin, Discord/Telegram hooks, transfer.sh …) | High |
| Calls a raw IP address / plain `http://` | High |
| **Secret typed into the flow** (literal API-key / Authorization header, Basic-auth password, OAuth secret, token in the URL) | High |
| Destination computed at run time (expression) | Medium |
| Host not on your allow-list (one-click **Allow**, kept in the browser) | Medium |
| Always emails fixed external recipients (set "your email domains") | Medium |
| Flow startable by HTTP request (check "who can trigger") | Info |

Tabs: **Findings** and **Destinations** (every host with flow count, environments, class), CSV exports, and **⏹ Stop flow** (turns the trigger off, read-back verified; nothing deleted; needs the *Stop flow as admin* operation, otherwise the button is disabled and the report says so).
Code: `src/egress/analyze.ts` (pure, tested on nested scope/if/else definitions), `live.ts`, `demo.ts`, `EgressView.tsx`.
**Limits:** only literal values are analysed (secrets in environment variables / Key Vault are correctly not flagged); custom connectors, child flows and Dataverse actions are not followed; flows whose definition cannot be read are reported as unknown, not safe; `*.sharepoint.com` / Microsoft domains are treated as Microsoft services (another tenant's SharePoint looks the same); `azurewebsites.net` and blob storage are treated as external. Reads are capped at 400 definitions per environment (started flows first). **Unverified live:** the query parameter that makes *Get Flow as Admin* return the definition is detected from the connector schema – if the Scan report says "returned NO definition", send me 🩺.

## v1.15.0 – 🤖 Agent Guard (new) + agent flows in Egress Radar
**Why:** Microsoft's own write-up *"Detecting and mitigating common agent misconfigurations"* (Copilot Studio agent security top-10) and several practitioner posts call out the same risks – agents with **no authentication**, tools running with the **maker's credentials**, over-broad access – but Microsoft's at-scale detection route is Defender Advanced Hunting (`AIAgentsInfo`). Agent Guard gives Power Platform admins a self-service view with no Defender and no app registration.
**Agent Guard** (header button 🤖, Ctrl K) reads every agent from Dataverse (`bot` + `botcomponent`; this app's own environment natively, others via the Dataverse connector):

| Finding | Severity |
|---|---|
| No authentication **and** a tool runs as the maker ("anyone with the link acts as the maker") | High |
| No authentication | High |
| HTTP request node to a capture/paste/tunnel service, raw IP, plain HTTP, or with a secret typed into the topic | High |
| Tools run with the maker's credentials | Medium |
| Grounded on a public website (untrusted input / prompt injection) | Medium |
| HTTP request node to a host not on the allow-list (allow-list shared with Egress Radar), destination computed at run time | Medium |
| Open to every signed-in user | Low |
| Settings / topics unreadable → *unknown, not safe* | Info |

**Agent flows & solution flows** are now analysed by 📡 Egress Radar too: they live in Dataverse (`workflow`, category 5, definition in `clientdata`), are tagged **agent flow**, and also fill the gap where *Get Flow as Admin* returns no definition.
**Unverified live – treat the first run as a pilot:** the Dataverse column names `authenticationmode` / `accesscontrolpolicy` and the numeric code→meaning map (None = 1, Integrated = 2 …; the raw value is shown next to every verdict and the Dataverse formatted value is preferred when returned); the YAML patterns used to find HTTP request nodes (`kind: HttpRequestAction`), maker-mode tools (`mode: Maker`) and public sites (`PublicSiteSearchSource`); `modernflowtype = 1` for agent flows. If a column is rejected the agent is shown as *unknown*, never as safe. Not read yet: who an agent is shared with, published channels, MCP servers, Entra group membership.
Code: `src/agents/` (`analyze.ts` pure + tested, `live.ts`, `demo.ts`, `AgentView.tsx`), `src/nav.tsx` (shared navigation across the five modules).
